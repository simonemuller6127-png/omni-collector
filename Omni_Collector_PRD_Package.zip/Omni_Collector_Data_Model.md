# Omni Collector Data Model

## Content Entity

字段：

-   id
-   canonical_title
-   similarity_score

## Collection

字段：

-   id
-   content_id
-   platform
-   url
-   title
-   original_title
-   status

## Comment

字段：

-   id
-   collection_id
-   content
-   like_count
-   status

## External Document

字段：

-   id
-   path
-   file_hash
-   file_id
-   modified_time

## AI Cache

字段：

-   input_hash
-   model
-   result
-   created_time
