# Omni Collector Development Task

## Phase 1

完成： - Obsidian插件框架 - SQLite - Markdown生成

## Phase 2

完成： - B站Adapter - 同步队列

## Phase 3

完成： - 多平台Adapter - 评论系统

## Phase 4

完成： - Topic - Series - AI模块

## Codex任务拆分

Task 001: 初始化插件

Task 002: 数据库Schema

Task 003: Markdown生成器

Task 004: 同步服务
