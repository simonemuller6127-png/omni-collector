# Omni Collector TDD Preparation

## Architecture

Platform Adapter ↓ Sync Service ↓ SQLite ↓ Markdown Manager ↓ Obsidian
Plugin

## Modules

-   Platform Adapter
-   Scheduler
-   Queue Manager
-   Storage Layer
-   Markdown Manager
-   External File Manager
-   AI Manager

## Adapter Interface

login() syncCollection() getDetail() getComments()

## Development Direction

先完成数据层，再扩展AI能力。
