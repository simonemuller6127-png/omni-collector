# Omni Collector V1.1 PRD Final

## 文档信息

项目：Omni Collector\
版本：V1.1 Revised Final Draft

## 版本说明

V1.1 在原 V1.0 PRD 基础上补充： - Content Entity 内容实体层 - 外部
Markdown 解析增强 - 数据版本管理 - AI任务优先级 - 多设备与备份策略 -
性能指标 - 测试体系

## 产品定位

Omni Collector 是跨平台收藏同步、本地知识整理、Obsidian增强系统。

核心流程：

互联网收藏 → 统一数据层 → 知识组织 → Markdown → Obsidian知识库

## 核心原则

1.  数据所有权归用户
2.  同步与AI解耦
3.  AI辅助而非替代用户
4.  低频、安全同步

## 核心模块

-   平台同步系统
-   Collection管理
-   Content Entity聚合
-   Tag/Topic知识组织
-   External Document索引
-   评论资产管理
-   AI增强系统
-   Obsidian交互层

## 新增补充需求

### Content Entity

用于解决同一内容来自不同平台的问题。

结构：

Content Entity - Bilibili Instance - YouTube Instance - Xiaohongshu
Instance

### 外部Markdown解析

支持： - 单文件路径导入 - Frontmatter解析 - Markdown AST解析 -
hash/file_id追踪 - 文件移动恢复

### 数据安全

支持： - SQLite备份 - schema_version - 数据迁移 - Cookie安全存储

## 开发路线

V1: 收藏统一管理

V2: 知识整理

V3: 个人AI知识助手

（完整版本请在此基础继续扩展原始Part1-Part10内容）
