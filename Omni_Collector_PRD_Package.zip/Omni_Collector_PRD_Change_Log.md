# Omni Collector PRD Change Log

## V1.0 → V1.1

新增：

1.  Content Entity实体层

原因： 跨平台相同内容不能简单去重。

2.  Markdown解析增强

原因： 支持任意外部Markdown文件。

3.  AI任务管理

新增： - AI Queue - Priority - Cache

4.  数据迁移

新增： - schema_version - backup - rollback

5.  性能验收指标

新增： - 大规模收藏支持 - 搜索性能要求
